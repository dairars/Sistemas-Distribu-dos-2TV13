#include <Socket_Servidor.h>
#include <Socket.h>
#include <string.h>
#include <stdio.h>

int pago(valor3){
	
	if(valor3<500){
	return 1;
	}else{
	return 0;
	}

}

main ()
{
	/*
	* Descriptores de socket servidor y de socket con el cliente
	*/
	int Socket_Servidor;
	int Socket_Cliente;
	char Cadena[100];
	char Cadena1[100];
	char Cadena2[100];
	char Cadena3[100];
	char Caden[100];
	char Caden1[100];
	char Caden2[100];
	char Caden3[100];
	char Caden4[100];
	int valor;
	int valor1;
	int valor2;
	int valor3;
	int final;
	

	/*
	* Se abre el socket servidor, con el servicio "cpp_java" dado de
	* alta en /etc/services.
	*/
	Socket_Servidor = Abre_Socket_Inet ("cpp_java");
	if (Socket_Servidor == -1)
	{
		printf ("No se puede abrir socket servidor\n");
		exit (-1);
	}

	/*
	* Se espera un cliente que quiera conectarse
	*/
	Socket_Cliente = Acepta_Conexion_Cliente (Socket_Servidor);
	if (Socket_Servidor == -1)
	{
		printf ("No se puede abrir socket de cliente\n");
		exit (-1);
	}

	/*
	Skeleton
	*/
	
	Lee_Socket (Socket_Cliente, Cadena, 3);
	printf ("Soy Servior, Conexion exitosa atendiendo turno: %s\n", Cadena);
	strcpy (Caden, "Atendiendo");
	Escribe_Socket (Socket_Cliente, Caden, 11);
	
	Lee_Socket (Socket_Cliente, Cadena1, 6);
	printf ("Numero de cuenta del cliente %s\n", Cadena1);
	strcpy (Caden1, "Recibido");
	Escribe_Socket (Socket_Cliente, Caden1, 9);
	
	Lee_Socket (Socket_Cliente, Cadena2, 4);
	printf ("CVV de cuenta : %s\n", Cadena2);
	strcpy (Caden2, "Recibido");
	Escribe_Socket (Socket_Cliente, Caden2, 9);
	
	Lee_Socket (Socket_Cliente, Cadena3, 4);
	printf ("Soy Servior, he recibido : %s\n", Cadena3);
	
	valor3 = atoi(Cadena3);
	printf ("Monto a cobrar: %d\n",valor3);
	
	pago(valor3);
	if(pago == 1){
	strcpy (Caden3, "La transaccion fue exitosa se confirma su pedido y su pedido esta en camino");
	Escribe_Socket (Socket_Cliente, Caden3, 76);
	}else{
	strcpy (Caden3, "La transaccion no fue exitosa intente otro metodo de pago");
	Escribe_Socket (Socket_Cliente, Caden3, 58);
	}
	
	
	
	strcpy (Caden4, "Adios");
	Escribe_Socket (Socket_Cliente, Caden4, 6);

	/*
	* Se cierran los sockets
	*/
	close (Socket_Cliente);
	close (Socket_Servidor);
}
