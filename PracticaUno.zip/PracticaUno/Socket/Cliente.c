#include <stdio.h>
#include <Socket_Cliente.h>
#include <Socket.h>

main ()
{
	int Socket_Con_Servidor;
   int Longitud_Cadena = 0;
   int Aux;
	char Cadena[100];

	Socket_Con_Servidor = Abre_Conexion_Inet ("localhost", "cpp_java");
	if (Socket_Con_Servidor == 1)
	{
		printf ("No puedo establecer conexion con el servidor\n");
		exit (-1);
	}

   Lee_Socket (Socket_Con_Servidor, (char *)&Aux, sizeof(int));
   Longitud_Cadena = ntohl (Aux);
   printf ("Cliente en C: Recibido correctamente %d\n", Longitud_Cadena-1);

   Lee_Socket (Socket_Con_Servidor, Cadena, Longitud_Cadena);
   printf ("Cliente en C: Recibido correctamente %s\n", Cadena);
   
	strcpy (Cadena, "Adios");
   Longitud_Cadena = 6;

   Aux = htonl (Longitud_Cadena);
   Escribe_Socket (Socket_Con_Servidor, (char *)&Aux, sizeof(Longitud_Cadena));
   printf ("Cliente en C: Enviado correctamente %d\n", Longitud_Cadena-1);

	Escribe_Socket (Socket_Con_Servidor, Cadena, Longitud_Cadena);
   printf ("Cliente en C: Enviado correctamente %s\n", Cadena);

	close (Socket_Con_Servidor);
}
