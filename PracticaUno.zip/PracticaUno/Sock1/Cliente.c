/*
* Javier Abellan, 20 Jun 2000
*
* Programa Cliente de un socket INET, como ejemplo de utilizacion
* de las funciones de sockets
*/
#include <stdio.h>
#include <Socket_Cliente.h>
#include <Socket.h>

main ()
{
	/*
	* Descriptor del socket y buffer para datos
	*/
	int Socket_Con_Servidor;
	char Cadena[100];
	char Cadena1[100];
	char Cadena2[100];
	char Cadena3[100];
	/*
	* Se abre la conexion con el servidor, pasando el nombre del ordenador
	* y el servicio solicitado.
	* "localhost" corresponde al nombre del mismo ordenador en el que
	* estamos corriendo. Esta dado de alta en /etc/hosts
	* "cpp_java" es un servicio dado de alta en /etc/services
	*/
	Socket_Con_Servidor = Abre_Conexion_Inet ("localhost", "cpp_java");
	if (Socket_Con_Servidor == 1)
	{
		printf ("No puedo establecer conexion con el servidor\n");
		exit (-1);
	}

	/*
	* Se prepara una cadena con 5 caracteres y se envia, 4 letras mas
	* el \0 que indica fin de cadena en C
	*/
	do{
	printf ("Escribe el primer numero: ");
	scanf("%s",Cadena);
	Escribe_Socket (Socket_Con_Servidor, Cadena, 3);
	Lee_Socket (Socket_Con_Servidor, Cadena, 9);
	printf ("Soy cliente, He recibido : %s\n", Cadena);
	
	printf ("Escribe el segundo numero: ");
	scanf("%s",Cadena1);
	Escribe_Socket (Socket_Con_Servidor, Cadena1, 3);
	Lee_Socket (Socket_Con_Servidor, Cadena1, 10);
	printf ("Soy cliente, He recibido : %s\n", Cadena1);
	
	printf ("Escribe el tercer numero: ");
	scanf("%s",Cadena2);
	Escribe_Socket (Socket_Con_Servidor, Cadena2, 3);
	Lee_Socket (Socket_Con_Servidor, Cadena2, 10);
	printf ("Soy cliente, He recibido : %s\n", Cadena2);
	
	printf ("Escribe el cuarto numero: ");
	scanf("%s",Cadena3);
	Escribe_Socket (Socket_Con_Servidor, Cadena3, 3);
	Lee_Socket (Socket_Con_Servidor, Cadena3, 6);
	printf ("Soy cliente, He recibido : %s\n", Cadena3);
	}
	while(Cadena3!="Recibido");
	
	/*
	* Se cierra el socket con el servidor
	*/
	close (Socket_Con_Servidor);
}
