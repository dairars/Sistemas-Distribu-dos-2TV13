/*
* Javier Abellan, 20 Jun 2000
*
* Programa Servidor de socket INET, como ejemplo de utilizacion de las
* funciones de sockets.
*/
#include <Socket_Servidor.h>
#include <Socket.h>
#include <string.h>
#include <stdio.h>

main ()
{
	/*
	* Descriptores de socket servidor y de socket con el cliente
	*/
	int Socket_Servidor;
	int Socket_Cliente;
	char Cadena[100];
	char Cadena1[100];
	char Cadena2[100];
	char Cadena3[100];
	char Caden[100];
	char Caden1[100];
	char Caden2[100];
	char Caden3[100];
	int valor;
	int valor1;
	int valor2;
	int valor3;
	int final;
	

	/*
	* Se abre el socket servidor, con el servicio "cpp_java" dado de
	* alta en /etc/services.
	*/
	Socket_Servidor = Abre_Socket_Inet ("cpp_java");
	if (Socket_Servidor == -1)
	{
		printf ("No se puede abrir socket servidor\n");
		exit (-1);
	}

	/*
	* Se espera un cliente que quiera conectarse
	*/
	Socket_Cliente = Acepta_Conexion_Cliente (Socket_Servidor);
	if (Socket_Servidor == -1)
	{
		printf ("No se puede abrir socket de cliente\n");
		exit (-1);
	}

	/*
	* Se lee la informacion del cliente, suponiendo que va a enviar 
	* 5 caracteres.
	*/

	/*
	* Se prepara una cadena de texto para enviar al cliente. La longitud
	* de la cadena es 5 letras + \0 al final de la cadena = 6 caracteres
	*/
	do{
	Lee_Socket (Socket_Cliente, Cadena, 3);
	printf ("Soy Servior, he recibido : %s\n", Cadena);
	strcpy (Caden, "Recibido");
	Escribe_Socket (Socket_Cliente, Caden, 9);
	
	Lee_Socket (Socket_Cliente, Cadena1, 3);
	printf ("Soy Servior, he recibido : %s\n", Cadena1);
	strcpy (Caden1, "Recibido2");
	Escribe_Socket (Socket_Cliente, Caden1, 10);
	
	Lee_Socket (Socket_Cliente, Cadena2, 3);
	printf ("Soy Servior, he recibido : %s\n", Cadena2);
	strcpy (Caden2, "Recibido3");
	Escribe_Socket (Socket_Cliente, Caden2, 10);
	
	Lee_Socket (Socket_Cliente, Cadena3, 3);
	printf ("Soy Servior, he recibido : %s\n", Cadena3);
	
	valor = atoi(Cadena);
	valor1 = atoi(Cadena1);
	valor2 = atoi(Cadena2);
	valor3 = atoi(Cadena3);
	final = (((valor + valor1) * valor2) - valor3);
	printf ("El Resultado es: %d\n",final);
	if(final<500){
	strcpy (Caden, "Recibido");
	Escribe_Socket (Socket_Cliente, Caden, 9);
	}
	}
	while(final<500);
	strcpy (Caden3, "Adios");
	Escribe_Socket (Socket_Cliente, Caden3, 6);

	/*
	* Se cierran los sockets
	*/
	close (Socket_Cliente);
	close (Socket_Servidor);
}
