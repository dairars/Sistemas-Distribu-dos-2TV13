/*
 * Incluimos las funciones de suma, resta, multiplicacion y division, aqui es donde se realizara la operacion, nuestros parametros son 
   los ya enviados por el cliente, al final retornaremos el resultado
 */

#include "calculate.h"

float * add_1_svc(inputs *argp, struct svc_req *rqstp)
{
	static float  result;

	result = argp->num1+argp->num2;
	printf("Se solicito: Sumando %.2f y %.2f\n", argp->num1, argp->num2);
	printf("Respuesta enviada: %.2f\n", result);

	return &result;
}

float * sub_1_svc(inputs *argp, struct svc_req *rqstp)
{
	static float  result;

	result = argp->num1-argp->num2;
	printf("Se solicito: Restando %.2f y %.2f\n", argp->num1, argp->num2);
	printf("Respuesta enviada: %.2f\n", result);

	return &result;
}

float * mul_1_svc(inputs *argp, struct svc_req *rqstp)
{
	static float  result;

	result = argp->num1*argp->num2;
	printf("Se solicito: Multiplicando %.2f y %.2f\n", argp->num1, argp->num2);
	printf("Respuesta enviada: %.2f\n", result);

	return &result;
}

float *
div_1_svc(inputs *argp, struct svc_req *rqstp)
{
	static float  result;

	result = argp->num1/argp->num2;
	printf("Se solicito: Dividiendo %.2f y %.2f\n", argp->num1, argp->num2);
	printf("Respuesta enviada: %.2f\n", result);

	return &result;
}
