/*
 * En este programa tenemos los datos de entrada y los apuntadores a los resultados de cada uno de los operadores
 * Tenemos condicionales que son activados a recibir alguno de los operadores (+, -, *, /), al entrar al condicional asigna los valores de 
 los dos numeros pedidos y del operador, y al apuntador le asignamos los datos de entrada con lo sparametros correspondientes, al final
 retornamos el valor del apuntador.
 * Creemos que los nombres de las variables son comprensibles y se pueden identificar facilmente

 *En el main tenemos los menjes para pedir los valores y el operador en forma de menu, los numeros se guardan en tipo float, y el operador en 
 tipo char, al final mostramos el resultado y cerramos el cliente.
 */

#include "calculate.h"

float calculate_prog_1(char *host, float n1, float n2, char opr, CLIENT *clnt)
{
	float  *result_1;
	inputs  add_1_arg;
	float  *result_2;
	inputs  sub_1_arg;
	float  *result_3;
	inputs  mul_1_arg;
	float  *result_4;
	inputs  div_1_arg;

if(opr=='+'){
	
	add_1_arg.num1=n1;
	add_1_arg.num2=n2;
	add_1_arg.operator=opr;

	result_1 = add_1(&add_1_arg, clnt);
	if (result_1 == (float *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	return *result_1;
}

else if(opr=='-'){
	sub_1_arg.num1=n1;
	sub_1_arg.num2=n2;
	sub_1_arg.operator=opr;

	result_2 = sub_1(&sub_1_arg, clnt);
	if (result_2 == (float *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	return *result_2;
}
else if(opr=='*'){
	mul_1_arg.num1=n1;
	mul_1_arg.num2=n2;
	mul_1_arg.operator=opr;

	result_3 = mul_1(&mul_1_arg, clnt);
	if (result_3 == (float *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	return *result_3;
}
	else if(opr=='/'){
	div_1_arg.num1=n1;
	div_1_arg.num2=n2;
	div_1_arg.operator=opr;
	if(n2==0){
	printf("Division entre 0 no es valida\n");
	exit(0);
}
	else{

	result_4 = div_1(&div_1_arg, clnt);
	if (result_4 == (float *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	return *result_4;
}
}
}

int main (int argc, char *argv[])
{
	char *host;
	float a,b;
	char op;
	CLIENT *clnt;

	if (argc < 2) {
		printf ("usage: %s server_host\n", argv[0]);
		exit (1);
	}

	printf("Bienvenido a la calculadora\n");
	printf("+ Suma\n- Resta\n* Multiplicación\n / División\n");
	printf("Teclee el 1er numero:\n");
	scanf("%f",&a);
	printf("Teclee el 2do numero:\n");
	scanf("%f",&b);
	printf("Teclee el operador:\n");
	scanf("%s",&op);
	
	host = argv[1];
	clnt = clnt_create (host, CALCULATE_PROG, CALCULATE_VER, "udp");
	if(clnt == NULL){
	clnt_pcreateerror (host);
	exit(1);
	}
	printf("La respuesta es: %.2f\n", calculate_prog_1(host,a,b,op,clnt));
	clnt_destroy(clnt);
	exit (0);
}
